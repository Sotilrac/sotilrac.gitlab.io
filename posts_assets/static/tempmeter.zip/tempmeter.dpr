program tempmeter;

uses
  Forms,
  temperature in 'temperature.pas' {Form1},
  TimeStampCounter in '..\..\Dox\Delphi\TimeStampCounter.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
