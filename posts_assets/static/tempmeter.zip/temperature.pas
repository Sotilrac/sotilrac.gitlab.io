unit temperature;

{ author Natan Osterman,
         natan@email.si
         http://natan.zejn.si

         (c) 2000
}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, TimeStampCounter, ExtCtrls;



type
  TForm1 = class(TForm)
    Button1: TButton;
    Button6: TButton;
    Button7: TButton;
    Label2: TLabel;
    GroupBox1: TGroupBox;
    tempLabel: TLabel;
    Button2: TButton;
    Timer2: TTimer;
    Memo1: TMemo;
    Label3: TLabel;
    Label1: TLabel;
    Label4: TLabel;
    Button3: TButton;
    Edit1: TEdit;
    Label5: TLabel;
    Edit2: TEdit;
    Label6: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);

    procedure Button6Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Bon5Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);

    function  ReadPort(Port: word): byte;
    procedure Button8Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure Timer2Timer(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    temp:real;
    startt,stopt:int64;
    Fport : integer;
  aDCb : tdcb;
  i:integer;
  end;

var
  Form1: TForm1;
  potek:array[1..400] of real;

implementation

{$R *.DFM}
function TForm1.ReadPort(Port: word): byte; assembler; register;
asm
	 mov dx,Port
	 cli
	 in al,dx
	 sti
end;


procedure TForm1.Button1Click(Sender: TObject);
begin
CalibrateTSC;
Label2.Caption:='Clock: '+FloatToStrF(CpuSpeed,ffFixed,8,2)+' MHz';
end;

procedure TForm1.Button2Click(Sender: TObject);
begin


if not timer2.Enabled then
  begin
   i:=1;
   button2.caption:='Stop';
   memo1.lines.Clear;
  timer2.enabled:=True;
  end
  else
   begin
  timer2.enabled:=False;
   button2.caption:='Log';
  end;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  FPort:=CreateFile (pchar('COM1'),
                    GENERIC_READ or GENERIC_WRITE,0,NIl,
                    OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);

end;

procedure TForm1.Button4Click(Sender: TObject);
var us:real;
begin
Stopt:=gettsc;

us:=(StopT-startT)/CpuSpeed;


end;



procedure TForm1.Button6Click(Sender: TObject);
begin
  FPort:=CreateFile (pchar('COM2'),
                    GENERIC_READ or GENERIC_WRITE,0,NIl,
                    OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);

end;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
Button7.Caption:='Start';
  closeHandle (fPort);
end;

procedure TForm1.Bon5Click(Sender: TObject);

begin

EscapeCommFunction (FPort,CLRDTR)

end;

procedure TForm1.Button7Click(Sender: TObject);
var muc:dword;
    upor,us:REal;
    a,b: real;
begin
if Button7.Caption='Start' then Button7.Caption:='Stop'
else Button7.Caption:='Start';

while Button7.Caption='Stop' do begin
     EscapeCommFunction (FPort,SETDTR);
     startt:=GetTsc;
     muc:=0;
while (muc =0) do begin

           GetCommModemStatus(Fport,muc);
           Application.ProcessMessages;
           end;
     stopt:=GetTsc;

us:=(StopT-startT)/CpuSpeed;
//edit3.text:=FloatToStrF(us,ffGeneral,8,8);
EscapeCommFunction (FPort,CLRDTR);

label3.caption:=IntToStr(round(us));
{
upor:=0.0178*us/1000-0.424;
if upor>0 then begin
label1.caption:='R = '+IntTOStr(Round(upor*1000))+' Ohm';

temp:=1/(K+C*ln(upor))-273.16;
 }
 a:=StrToFloat(edit1.text);
 b:=StrToFloat(edit2.text);
 temp:=a*1/ln(us)+b;

tempLabel.caption:=FloatToStrF(temp,ffFixed,8,2);
{end
else begin
label1.caption:='Error. R too low!';
beep;
end;}
sleep(500);
Application.ProcessMessages;
end;

end;


procedure TForm1.Button8Click(Sender: TObject);
begin
     EscapeCommFunction (FPort,SETDTR);
end;

procedure TForm1.Timer1Timer(Sender: TObject);

var muc:dword;
begin
GetCommModemStatus(Fport,muc);
edit1.text:=IntToStr( (muc ));
end;

procedure TForm1.Timer2Timer(Sender: TObject);
begin
potek[i]:=temp;
Memo1.Lines.Add(FloatToStrF(temp,ffFixed,8,2));
inc(i);
end;

end.
