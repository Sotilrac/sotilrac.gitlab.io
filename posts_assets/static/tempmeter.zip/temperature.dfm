object Form1: TForm1
  Left = 199
  Top = 182
  Width = 413
  Height = 335
  Caption = 'PC Thermometer by natan@email.si'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object Label2: TLabel
    Left = 160
    Top = 40
    Width = 31
    Height = 13
    Caption = 'Speed'
  end
  object Label5: TLabel
    Left = 192
    Top = 96
    Width = 16
    Height = 13
    Caption = 'A ='
  end
  object Label6: TLabel
    Left = 192
    Top = 128
    Width = 16
    Height = 13
    Caption = 'B ='
  end
  object Button1: TButton
    Left = 48
    Top = 32
    Width = 75
    Height = 25
    Caption = 'Calibrate'
    TabOrder = 0
    OnClick = Button1Click
  end
  object Button6: TButton
    Left = 48
    Top = 96
    Width = 75
    Height = 25
    Caption = 'Open COM2'
    TabOrder = 1
    OnClick = Button6Click
  end
  object Button7: TButton
    Left = 48
    Top = 128
    Width = 75
    Height = 25
    Caption = 'Start'
    TabOrder = 2
    OnClick = Button7Click
  end
  object GroupBox1: TGroupBox
    Left = 48
    Top = 176
    Width = 233
    Height = 113
    Caption = 'Data'
    TabOrder = 3
    object tempLabel: TLabel
      Left = 160
      Top = 65
      Width = 5
      Height = 24
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -19
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
    object Label3: TLabel
      Left = 160
      Top = 33
      Width = 5
      Height = 24
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -19
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
    object Label1: TLabel
      Left = 16
      Top = 33
      Width = 78
      Height = 24
      Caption = 'Time [us]'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -19
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
    object Label4: TLabel
      Left = 16
      Top = 65
      Width = 84
      Height = 24
      Caption = 'Temp [�C]'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -19
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
  end
  object Button2: TButton
    Left = 295
    Top = 32
    Width = 75
    Height = 25
    Caption = 'Log'
    TabOrder = 4
    OnClick = Button2Click
  end
  object Memo1: TMemo
    Left = 295
    Top = 64
    Width = 75
    Height = 225
    Lines.Strings = (
      '')
    TabOrder = 5
  end
  object Button3: TButton
    Left = 48
    Top = 64
    Width = 75
    Height = 25
    Caption = 'Open COM1'
    TabOrder = 6
    OnClick = Button3Click
  end
  object Edit1: TEdit
    Left = 216
    Top = 96
    Width = 41
    Height = 21
    TabOrder = 7
    Text = '2707'
  end
  object Edit2: TEdit
    Left = 216
    Top = 128
    Width = 41
    Height = 21
    TabOrder = 8
    Text = '-215'
  end
  object Timer2: TTimer
    Enabled = False
    OnTimer = Timer2Timer
    Left = 264
    Top = 8
  end
end
